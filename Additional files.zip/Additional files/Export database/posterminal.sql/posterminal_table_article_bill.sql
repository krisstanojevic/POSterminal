
-- --------------------------------------------------------

--
-- Table structure for table `article_bill`
--

DROP TABLE IF EXISTS `article_bill`;
CREATE TABLE IF NOT EXISTS `article_bill` (
  `article_id` int(10) UNSIGNED NOT NULL,
  `bill_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `article_bill_article_id_foreign` (`article_id`),
  KEY `article_bill_bill_id_foreign` (`bill_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
