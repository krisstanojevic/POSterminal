
-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
CREATE TABLE IF NOT EXISTS `countries` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pdv` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name`, `pdv`, `created_at`, `updated_at`) VALUES
(1, 'China', 15, '2018-05-15 10:22:29', '2018-05-15 10:22:29'),
(2, 'Canada', 25, '2018-05-15 10:22:29', '2018-05-15 10:22:29'),
(3, 'Serbia', 20, '2018-05-15 10:22:29', '2018-05-15 10:22:29'),
(4, 'Turkey', 10, '2018-05-15 10:22:29', '2018-05-15 10:22:29'),
(5, 'India', 15, '2018-05-15 10:22:29', '2018-05-15 10:22:29'),
(6, 'France', 30, '2018-05-15 10:22:29', '2018-05-15 10:22:29'),
(7, 'Germany', 26, '2018-05-15 10:22:29', '2018-05-15 10:22:29'),
(8, 'Bangladesh', 15, '2018-05-15 10:22:29', '2018-05-15 10:22:29'),
(9, 'Italy', 32, '2018-05-15 10:22:29', '2018-05-15 10:22:29');
