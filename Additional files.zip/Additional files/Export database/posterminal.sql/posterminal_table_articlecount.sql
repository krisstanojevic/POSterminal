
-- --------------------------------------------------------

--
-- Table structure for table `articlecount`
--

DROP TABLE IF EXISTS `articlecount`;
CREATE TABLE IF NOT EXISTS `articlecount` (
  `article_id` int(10) UNSIGNED NOT NULL,
  `country_id` int(10) UNSIGNED NOT NULL,
  `count` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `articlecount_article_id_foreign` (`article_id`),
  KEY `articlecount_country_id_foreign` (`country_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
